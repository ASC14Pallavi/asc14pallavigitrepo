export interface Catalogue {
    id: string;
    title: string;
    author: string;
    publicationYear: number;
    status: string;
  }
  