export interface Member {
    id?: string; // Optional because the backend generates it
    name: string;
    email: string;
    phone: string;
  }
  
